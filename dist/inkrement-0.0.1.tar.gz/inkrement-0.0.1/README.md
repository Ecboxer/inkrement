# Inkrement #  
Matplotlib wrapper for incremental data analysis  

## Installing ##  

#### Requirements ####  
Matplotlib
