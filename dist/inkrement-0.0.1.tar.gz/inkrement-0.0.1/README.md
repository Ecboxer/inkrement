# Inkrement #  
Matplotlib wrapper for incremental data analysis  

#### Requirements ####  
Matplotlib
